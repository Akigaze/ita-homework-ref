


export const INCREMENT = "INCREMENT"
export const DECREMENT = "DECREMENT"
export const MULTIPLE = "MULTIPLE"