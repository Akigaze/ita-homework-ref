package com.thoughtworks.jpa.practices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaPracticesApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaPracticesApplication.class, args);
	}
}
