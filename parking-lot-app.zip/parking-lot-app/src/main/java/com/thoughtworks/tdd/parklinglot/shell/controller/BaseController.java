package com.thoughtworks.tdd.parklinglot.shell.controller;

public interface BaseController {

    String process();
}
