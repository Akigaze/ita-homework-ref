package com.thoughtworks.tdd.parklinglot.shell.io;

public class Response {
    public void send(String message) {
        System.out.println(message);
    }
}
